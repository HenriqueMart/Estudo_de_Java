/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.ifba.heranca;

/**
 *
 * @author hmart
 */
public class Zoologico {
    //Criando os atributos
    Cachorro cach;
    Cavalo cav;
    PeixeBoi pei;
    Preguica pre;
    Animal jaula[] = new Animal[10];
    
}
